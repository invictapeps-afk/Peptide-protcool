import { useState } from "react";

// ─── DATA ────────────────────────────────────────────────────────────────────

const protocols = [
  {
    id: "retatrutide", name: "Retatrutide", short: "RT", tag: "GLP-1/GIP/Glucagon", color: "#FF6B6B",
    subtitle: "Triple receptor agonist. Weekly subQ injection.",
    storage: { opened: "28 days refrigerated (2–8°C)", unopened: "Until expiry frozen (−20°C)", light: "Keep away from light" },
    reconSteps: [
      { icon: "🧴", title: "Gather supplies", text: "Vial of peptide, BAC water, 1 mL insulin syringe, alcohol swabs, and a clean surface." },
      { icon: "🧼", title: "Wash hands", text: "Wash thoroughly with soap for 20 seconds. Dry with a clean towel." },
      { icon: "💧", title: "Wipe vial tops", text: "Wipe the rubber stopper of both the peptide vial and BAC water with separate alcohol swabs. Let dry 30 seconds." },
      { icon: "💉", title: "Draw BAC water", text: "Draw the prescribed mL of BAC water slowly into the syringe. Remove all air bubbles." },
      { icon: "🧪", title: "Inject into peptide vial", text: "Insert needle at an angle into the peptide vial. Let the BAC water run down the inside wall — do NOT shoot directly onto the powder." },
      { icon: "🔄", title: "Gently swirl", text: "Gently roll the vial between your palms for 30–60 seconds. Never shake — this degrades the peptide." },
      { icon: "🔍", title: "Inspect solution", text: "The solution should be clear and colorless. Discard if cloudy, discolored, or contains particles." },
      { icon: "🏷️", title: "Label & store", text: "Label with date reconstituted. Store in the refrigerator at 2–8°C immediately." },
    ],
    vials: [
      { mg: 2,  bac: 1, concentration: "2 mg/mL",   note: "Starter vial — 8 doses at 0.25 mg" },
      { mg: 5,  bac: 2, concentration: "2.5 mg/mL", note: "~10 doses at 0.5 mg each" },
      { mg: 10, bac: 2, concentration: "5 mg/mL",   note: "10 doses at 1 mg or 5 doses at 2 mg" },
      { mg: 15, bac: 3, concentration: "5 mg/mL",   note: "~7–15 doses depending on protocol" },
      { mg: 20, bac: 4, concentration: "5 mg/mL",   note: "~10 doses at 2 mg; 4-week supply" },
      { mg: 30, bac: 4, concentration: "7.5 mg/mL", note: "~15 doses at 2 mg; 6-week supply" },
      { mg: 40, bac: 5, concentration: "8 mg/mL",   note: "~20 doses at 2 mg; 8-week supply" },
    ],
    tiers: {
      low:  { label: "0.5–1 mg/wk",  conservativeLabel: "0.25–0.5 mg/wk", items: [{ icon: "🎯", label: "Start", detail: "0.5 mg/wk for first 4 weeks. Gentle titration.", conservative: "Begin at 0.25 mg/wk. Slower titration reduces GI side effects." },{ icon: "⚡", label: "Effect", detail: "Mild appetite suppression, GI adaptation.", conservative: "Appetite changes may be subtle at conservative doses. Allow 4–6 weeks." },{ icon: "🔁", label: "Frequency", detail: "Once weekly subQ.", conservative: "Once weekly. Do not increase frequency." },{ icon: "📅", label: "Duration", detail: "4–8 weeks at this dose.", conservative: "6–10 weeks minimum; don't rush titration." },{ icon: "⏱", label: "Timing", detail: "Same day weekly; any time of day.", conservative: "Pick a consistent day and stick to it." }] },
      mid:  { label: "2–4 mg/wk",    conservativeLabel: "1–2 mg/wk",      items: [{ icon: "🎯", label: "Start", detail: "2 mg/wk after tolerating lower dose.", conservative: "1 mg/wk after 6 weeks at low dose with no issues." },{ icon: "⚡", label: "Effect", detail: "Significant appetite reduction, early weight loss.", conservative: "Gradual loss expected. Conservative dose reduces nausea risk." },{ icon: "🔁", label: "Frequency", detail: "Once weekly subQ.", conservative: "Once weekly only." },{ icon: "📅", label: "Duration", detail: "8–12 weeks standard maintenance.", conservative: "10–14 weeks at conservative pace." },{ icon: "⏱", label: "Timing", detail: "Consistent weekly window preferred.", conservative: "Consistent day and time weekly." }] },
      high: { label: "6–8 mg/wk",    conservativeLabel: "2–4 mg/wk",      items: [{ icon: "🎯", label: "Start", detail: "Up to 8 mg/wk under close supervision.", conservative: "Cap at 4 mg/wk unless provider explicitly advises higher." },{ icon: "⚡", label: "Effect", detail: "~24% body weight loss seen in TRIUMPH trials.", conservative: "Expect 10–15% loss at conservative doses; still significant." },{ icon: "🔁", label: "Frequency", detail: "Once weekly; monitor closely.", conservative: "Once weekly strictly. Monthly labs recommended." },{ icon: "📅", label: "Duration", detail: "48-week trial duration; ongoing as tolerated.", conservative: "Check in with provider every 8 weeks." },{ icon: "⏱", label: "Timing", detail: "Consistent weekly dosing.", conservative: "Same day, same window each week." }] },
    },
  },
  {
    id: "bpc157", name: "BPC-157", short: "BPC", tag: "Peptide", color: "#22C98A",
    subtitle: "Body protection compound. Daily subQ or oral.",
    storage: { opened: "30 days refrigerated (2–8°C)", unopened: "Until expiry frozen (−20°C)", light: "Protect from light; amber vial preferred" },
    reconSteps: [
      { icon: "🧴", title: "Gather supplies", text: "BPC-157 vial, BAC water, insulin syringe, alcohol swabs, clean surface." },
      { icon: "🧼", title: "Wash hands", text: "Thorough 20-second wash. Dry completely before handling." },
      { icon: "💧", title: "Swab both vials", text: "Alcohol swab the rubber stoppers of peptide vial and BAC water. Allow 30 seconds to dry." },
      { icon: "💉", title: "Draw BAC water", text: "Draw prescribed mL of BAC water. Tap syringe and expel air bubbles." },
      { icon: "🧪", title: "Slow wall injection", text: "Angle needle against the inside glass wall of the peptide vial. Let liquid trickle down slowly — never force it onto the powder." },
      { icon: "🔄", title: "Roll, don't shake", text: "Roll gently between palms for 45 seconds until fully dissolved. The peptide is fragile." },
      { icon: "🔍", title: "Inspect", text: "Should be clear and colorless. Discard if cloudy or particulate matter is visible." },
      { icon: "🏷️", title: "Label & refrigerate", text: "Date the vial. Refrigerate immediately at 2–8°C. Use within 30 days." },
    ],
    vials: [
      { mg: 2,  bac: 1, concentration: "2 mg/mL",   note: "~8 doses at 250 mcg" },
      { mg: 5,  bac: 2, concentration: "2.5 mg/mL", note: "~10 doses at 500 mcg" },
      { mg: 10, bac: 2, concentration: "5 mg/mL",   note: "~20 doses at 500 mcg; 3-week supply" },
      { mg: 15, bac: 3, concentration: "5 mg/mL",   note: "~30 doses at 500 mcg" },
      { mg: 20, bac: 4, concentration: "5 mg/mL",   note: "~40 doses; 5–6 week supply at 1 mg/day" },
      { mg: 25, bac: 5, concentration: "5 mg/mL",   note: "~50 doses at 500 mcg" },
      { mg: 30, bac: 5, concentration: "6 mg/mL",   note: "~60 doses; 2-month supply at 500 mcg/day" },
    ],
    tiers: {
      low:  { label: "250–500 mcg/day", conservativeLabel: "100–250 mcg/day", items: [{ icon: "🎯", label: "Start", detail: "250 mcg/day subQ for weeks 1–2.", conservative: "100–150 mcg/day for first 2 weeks to assess sensitivity." },{ icon: "⚡", label: "Effect", detail: "Anti-inflammatory, early gut repair.", conservative: "Subtle effects at low dose; allow 3–4 weeks to assess." },{ icon: "🔁", label: "Frequency", detail: "Once daily subQ.", conservative: "Once daily only; do not split or double dose." },{ icon: "📅", label: "Duration", detail: "4–6 weeks; assess response.", conservative: "6–8 weeks; slower progression is fine." },{ icon: "⏱", label: "Timing", detail: "Morning fasted or pre-bed.", conservative: "Morning fasted; consistent timing helps response tracking." }] },
      mid:  { label: "500 mcg–1 mg/day", conservativeLabel: "250–500 mcg/day", items: [{ icon: "🎯", label: "Start", detail: "500 mcg/day after tolerating low dose.", conservative: "250 mcg/day after 4 weeks at low dose with no issues." },{ icon: "⚡", label: "Effect", detail: "Tissue repair, tendon & ligament healing.", conservative: "Healing effects present at lower doses; patience is key." },{ icon: "🔁", label: "Frequency", detail: "Once daily; can split to 2x.", conservative: "Once daily only at conservative tier." },{ icon: "📅", label: "Duration", detail: "8–12 week cycle.", conservative: "10–12 weeks; don't rush." },{ icon: "⏱", label: "Timing", detail: "Pre-bed preferred; fasted 2+ hrs.", conservative: "Pre-bed fasted; consistent daily window." }] },
      high: { label: "1–2 mg/day", conservativeLabel: "500 mcg–1 mg/day", items: [{ icon: "🎯", label: "Start", detail: "1 mg/day for acute injury recovery.", conservative: "500 mcg/day; increase only if no improvement after 4 weeks." },{ icon: "⚡", label: "Effect", detail: "Accelerated healing, nerve repair support.", conservative: "Meaningful healing occurs at 500 mcg; higher isn't always better." },{ icon: "🔁", label: "Frequency", detail: "Split AM/PM dosing.", conservative: "Once daily; split only if provider recommends." },{ icon: "📅", label: "Duration", detail: "4–8 weeks acute; reassess.", conservative: "6–8 weeks; reassess with provider before continuing." },{ icon: "⏱", label: "Timing", detail: "Split AM/PM fasted.", conservative: "Pre-bed fasted; morning option if needed." }] },
    },
  },
  {
    id: "cjc", name: "CJC w/ DAC", short: "CJC", tag: "GHRH", color: "#4A9EFF",
    subtitle: "Long-acting GHRH analogue. Weekly subQ.",
    storage: { opened: "21 days refrigerated (2–8°C)", unopened: "Until expiry frozen (−20°C)", light: "Sensitive to light; store in original packaging" },
    reconSteps: [
      { icon: "🧴", title: "Gather supplies", text: "CJC vial, BAC water, insulin syringe, alcohol swabs." },
      { icon: "🧼", title: "Wash hands", text: "Full 20-second wash. Dry with clean paper towel." },
      { icon: "💧", title: "Swab stoppers", text: "Clean both vial stoppers with individual alcohol swabs. Let air dry." },
      { icon: "💉", title: "Draw BAC water", text: "Pull back syringe slowly for exact mL. Remove air." },
      { icon: "🧪", title: "Side-wall injection", text: "Aim needle at the inner glass wall — not the powder. Let BAC water run down slowly." },
      { icon: "🔄", title: "Gentle rolling", text: "Roll between palms slowly for 60 seconds. CJC with DAC is sensitive to agitation." },
      { icon: "🔍", title: "Check clarity", text: "Solution should be clear. Do not use if any cloudiness or color change is present." },
      { icon: "🏷️", title: "Date & store", text: "Label with reconstitution date. Refrigerate at 2–8°C. Use within 21 days." },
    ],
    vials: [
      { mg: 2,  bac: 1, concentration: "2 mg/mL",   note: "~2 doses at 1 mg" },
      { mg: 5,  bac: 2, concentration: "2.5 mg/mL", note: "~5 doses at 1 mg; 5-week supply" },
      { mg: 10, bac: 2, concentration: "5 mg/mL",   note: "~5 doses at 2 mg; 5-week supply" },
      { mg: 15, bac: 3, concentration: "5 mg/mL",   note: "~7 doses at 2 mg" },
      { mg: 20, bac: 4, concentration: "5 mg/mL",   note: "~10 doses at 2 mg; 10-week supply" },
      { mg: 30, bac: 5, concentration: "6 mg/mL",   note: "~15 doses at 2 mg; ~4-month supply" },
    ],
    tiers: {
      low:  { label: "1 mg/wk",  conservativeLabel: "0.5 mg/wk", items: [{ icon: "🎯", label: "Start", detail: "1 mg once weekly subQ for 4 weeks.", conservative: "0.5 mg/wk for first 4 weeks; assess GH response." },{ icon: "⚡", label: "Effect", detail: "Mild GH stimulation, improved sleep.", conservative: "Sleep improvement is often the first sign. Give it 3–4 weeks." },{ icon: "🔁", label: "Frequency", detail: "Once weekly (DAC half-life ~8 days).", conservative: "Once weekly strictly; DAC accumulates." },{ icon: "📅", label: "Duration", detail: "8–12 weeks per cycle.", conservative: "10–12 weeks; check IGF-1 before extending." },{ icon: "⏱", label: "Timing", detail: "Pre-bed for GH rhythm alignment.", conservative: "Pre-bed fasted 2–3 hours; avoid food before injection." }] },
      mid:  { label: "2 mg/wk",  conservativeLabel: "1 mg/wk",   items: [{ icon: "🎯", label: "Start", detail: "2 mg once weekly after tolerating 1 mg.", conservative: "Stay at 1 mg/wk for 6 weeks before considering 2 mg." },{ icon: "⚡", label: "Effect", detail: "Notable GH/IGF-1 elevation, body composition.", conservative: "IGF-1 should be monitored before and after a cycle." },{ icon: "🔁", label: "Frequency", detail: "Once weekly subQ.", conservative: "Once weekly; more frequent dosing is counterproductive with DAC." },{ icon: "📅", label: "Duration", detail: "12–16 week optimization cycle.", conservative: "12 weeks max; off-cycle IGF-1 check recommended." },{ icon: "⏱", label: "Timing", detail: "Pre-bed fasted.", conservative: "Pre-bed fasted consistently." }] },
      high: { label: "4 mg/wk",  conservativeLabel: "2 mg/wk",   items: [{ icon: "🎯", label: "Start", detail: "4 mg/wk; experienced users only.", conservative: "2 mg/wk is effective for most; 4 mg requires IGF-1 monitoring." },{ icon: "⚡", label: "Effect", detail: "Significant IGF-1 elevation, lean mass gains.", conservative: "At conservative 2 mg, lean mass effects are still meaningful." },{ icon: "🔁", label: "Frequency", detail: "Once weekly with monitoring.", conservative: "Once weekly; monthly IGF-1 blood work essential." },{ icon: "📅", label: "Duration", detail: "12 weeks on, 4 off.", conservative: "12 weeks strictly; minimum 4-week washout." },{ icon: "⏱", label: "Timing", detail: "Pre-bed fasted 2+ hrs.", conservative: "Pre-bed only; no food 2–3 hours prior." }] },
    },
  },
  {
    id: "ghkcu", name: "GHK-Cu", short: "GHK", tag: "Copper Peptide", color: "#F59E0B",
    subtitle: "Copper-binding tripeptide. SubQ or topical.",
    storage: { opened: "60 days refrigerated (2–8°C)", unopened: "Until expiry frozen (−20°C)", light: "Light-stable; standard storage OK" },
    reconSteps: [
      { icon: "🧴", title: "Gather supplies", text: "GHK-Cu vial, sterile water or BAC water, syringe, alcohol swabs." },
      { icon: "🧼", title: "Wash hands", text: "20-second wash. Dry with clean towel." },
      { icon: "💧", title: "Swab stoppers", text: "Wipe rubber tops with alcohol swabs. Let dry 30 seconds." },
      { icon: "💉", title: "Draw diluent", text: "Draw exact mL of BAC or sterile water into syringe." },
      { icon: "🧪", title: "Inject along wall", text: "Inject liquid slowly down the inside wall of the vial." },
      { icon: "🔄", title: "Roll gently", text: "Roll 30 seconds. GHK-Cu typically dissolves quickly and easily." },
      { icon: "🔍", title: "Inspect", text: "Should be clear; may have a very slight blue tint from copper — this is normal." },
      { icon: "🏷️", title: "Label & store", text: "Label with date. Refrigerate. Stable up to 60 days." },
    ],
    vials: [
      { mg: 50,  bac: 5,  concentration: "10 mg/mL", note: "~100 doses at 500 mcg" },
      { mg: 100, bac: 10, concentration: "10 mg/mL", note: "~200 doses at 500 mcg; long supply" },
      { mg: 200, bac: 10, concentration: "20 mg/mL", note: "~200 doses at 1 mg; 6+ month supply" },
    ],
    tiers: {
      low:  { label: "500 mcg/day", conservativeLabel: "200–300 mcg/day", items: [{ icon: "🎯", label: "Start", detail: "500 mcg/day subQ for 2 weeks.", conservative: "200–300 mcg/day; copper peptides are potent at lower doses." },{ icon: "⚡", label: "Effect", detail: "Antioxidant support, collagen stimulation.", conservative: "Collagen effects begin within 3–4 weeks at conservative doses." },{ icon: "🔁", label: "Frequency", detail: "Once daily subQ.", conservative: "Once daily; every other day is acceptable at start." },{ icon: "📅", label: "Duration", detail: "4–6 weeks; evaluate response.", conservative: "6–8 weeks at conservative pace." },{ icon: "⏱", label: "Timing", detail: "Morning or evening consistently.", conservative: "Same time daily; evening with skincare routine is practical." }] },
      mid:  { label: "1 mg/day",    conservativeLabel: "500 mcg/day",     items: [{ icon: "🎯", label: "Start", detail: "1 mg/day after 2 weeks at low dose.", conservative: "500 mcg/day after 4 weeks at low dose." },{ icon: "⚡", label: "Effect", detail: "Enhanced collagen, wound healing, anti-aging.", conservative: "Meaningful results at 500 mcg; no need to rush to 1 mg." },{ icon: "🔁", label: "Frequency", detail: "Once daily subQ; topical can supplement.", conservative: "Once daily subQ; topical creams optional." },{ icon: "📅", label: "Duration", detail: "8–12 week cycle.", conservative: "10–12 weeks; skin remodeling takes time." },{ icon: "⏱", label: "Timing", detail: "Evening preferred.", conservative: "Evening preferred for recovery alignment." }] },
      high: { label: "2 mg/day",    conservativeLabel: "1 mg/day",        items: [{ icon: "🎯", label: "Start", detail: "2 mg/day for accelerated remodeling.", conservative: "1 mg/day max; 2 mg offers diminishing returns for most." },{ icon: "⚡", label: "Effect", detail: "Strong pro-collagen, nerve & hair growth support.", conservative: "Hair and nerve effects emerge at 1 mg; monitor scalp response." },{ icon: "🔁", label: "Frequency", detail: "Once daily under guidance.", conservative: "Once daily; topical combination is conservative alternative." },{ icon: "📅", label: "Duration", detail: "8 weeks on, 4 off.", conservative: "8 weeks on; 4-week break before resuming." },{ icon: "⏱", label: "Timing", detail: "Evening fasted.", conservative: "Evening fasted for best tissue uptake." }] },
    },
  },
  {
    id: "glutathione", name: "Glutathione", short: "GSH", tag: "Antioxidant", color: "#A78BFA",
    subtitle: "Master antioxidant. IV, subQ, or nebulized.",
    storage: { opened: "7 days refrigerated (2–8°C)", unopened: "Until expiry frozen (−20°C)", light: "Very light-sensitive; wrap vial in foil if possible" },
    reconSteps: [
      { icon: "🧴", title: "Gather supplies", text: "Glutathione vial, sterile saline or BAC water, syringe, IV line (if IV push), alcohol swabs." },
      { icon: "🧼", title: "Wash hands", text: "Full wash and dry. Gloves recommended for IV prep." },
      { icon: "💧", title: "Wipe all ports", text: "Swab all injection ports and vial tops. Glutathione is particularly sensitive to contamination." },
      { icon: "💉", title: "Draw diluent", text: "Draw prescribed mL of saline or BAC water. For IV: mix into saline bag per provider instructions." },
      { icon: "🧪", title: "Reconstitute gently", text: "Add diluent to vial slowly along the wall. Glutathione oxidizes quickly — work efficiently." },
      { icon: "🔄", title: "Swirl briefly", text: "5–10 second gentle swirl only. Avoid excess agitation." },
      { icon: "🔍", title: "Check color", text: "Should be clear to slightly yellow. Discard if it turns brown or orange — that indicates oxidation." },
      { icon: "🏷️", title: "Use promptly", text: "Glutathione is unstable once reconstituted. Use within 7 days refrigerated. Light protection strongly advised." },
    ],
    vials: [
      { mg: 200,  bac: 10, concentration: "20 mg/mL",  note: "Single IV push or 10 subQ doses" },
      { mg: 600,  bac: 10, concentration: "60 mg/mL",  note: "Single IV push (standard clinic dose)" },
      { mg: 1200, bac: 10, concentration: "120 mg/mL", note: "Single high-dose IV; slow drip" },
      { mg: 2400, bac: 20, concentration: "120 mg/mL", note: "2x high-dose sessions; clinic use" },
      { mg: 5000, bac: 25, concentration: "200 mg/mL", note: "Multi-session bulk; intensive protocol" },
    ],
    tiers: {
      low:  { label: "200 mg/session",  conservativeLabel: "100–200 mg/session", items: [{ icon: "🎯", label: "Start", detail: "200 mg IV push or subQ 2–3x/week.", conservative: "100 mg to start; increase only if well tolerated." },{ icon: "⚡", label: "Effect", detail: "Foundational antioxidant, liver detox.", conservative: "Gentle detox support at conservative dose; ideal for sensitive individuals." },{ icon: "🔁", label: "Frequency", detail: "2–3x weekly.", conservative: "2x weekly to start; assess tolerance." },{ icon: "📅", label: "Duration", detail: "4–8 weeks intro protocol.", conservative: "6–8 weeks; allow body to adjust." },{ icon: "⏱", label: "Timing", detail: "Post-workout or morning.", conservative: "Morning fasted preferred." }] },
      mid:  { label: "600 mg/session",  conservativeLabel: "300–400 mg/session", items: [{ icon: "🎯", label: "Start", detail: "600 mg IV or subQ 2–3x weekly.", conservative: "300–400 mg/session; step up from 200 mg if tolerated." },{ icon: "⚡", label: "Effect", detail: "Brightening, immune boost, cellular repair.", conservative: "Skin and immune effects at 300–400 mg are clinically meaningful." },{ icon: "🔁", label: "Frequency", detail: "2–3x weekly consistently.", conservative: "2x weekly; consistent is better than more frequent." },{ icon: "📅", label: "Duration", detail: "8–12 weeks standard.", conservative: "10 weeks; reassess with provider at halfway." },{ icon: "⏱", label: "Timing", detail: "Morning or post-exercise.", conservative: "Morning fasted or post-workout." }] },
      high: { label: "1200 mg/session", conservativeLabel: "600–800 mg/session", items: [{ icon: "🎯", label: "Start", detail: "1200 mg IV push under clinical supervision.", conservative: "600–800 mg is effective; 1200 mg requires clinical setting." },{ icon: "⚡", label: "Effect", detail: "Maximum detox, skin lightening, mitochondrial support.", conservative: "600–800 mg achieves strong effect with lower risk of headache/nausea." },{ icon: "🔁", label: "Frequency", detail: "2x weekly IV.", conservative: "1–2x weekly; prioritize slow IV administration." },{ icon: "📅", label: "Duration", detail: "6–10 weeks; monitor liver enzymes.", conservative: "6–8 weeks; liver enzymes should be checked at start and end." },{ icon: "⏱", label: "Timing", detail: "Morning fasted clinic sessions.", conservative: "Morning fasted; slow drip over 30–60 min minimum." }] },
    },
  },
  {
    id: "ipamorelin", name: "Ipamorelin", short: "IPA", tag: "GHRP", color: "#34D399",
    subtitle: "Selective GH secretagogue. Daily subQ.",
    storage: { opened: "30 days refrigerated (2–8°C)", unopened: "Until expiry frozen (−20°C)", light: "Light-sensitive; store in box or wrapped" },
    reconSteps: [
      { icon: "🧴", title: "Gather supplies", text: "Ipamorelin vial, BAC water, insulin syringe, alcohol swabs." },
      { icon: "🧼", title: "Wash hands", text: "20 seconds minimum. Dry completely." },
      { icon: "💧", title: "Swab tops", text: "Alcohol swab both vial stoppers. Wait 30 seconds." },
      { icon: "💉", title: "Draw BAC water", text: "Pull syringe slowly. For small vials (2 mg), precision matters — use a 1 mL syringe." },
      { icon: "🧪", title: "Inject slowly", text: "Run liquid down inside wall of the peptide vial. Ipamorelin dissolves readily." },
      { icon: "🔄", title: "Gentle swirl", text: "Roll between palms for 20–30 seconds. Should dissolve quickly and completely." },
      { icon: "🔍", title: "Inspect", text: "Clear, colorless solution. Discard if any cloudiness present." },
      { icon: "🏷️", title: "Label & store", text: "Date the vial. Refrigerate. Use within 30 days of reconstitution." },
    ],
    vials: [
      { mg: 2,  bac: 1, concentration: "2 mg/mL",   note: "~20 doses at 100 mcg" },
      { mg: 5,  bac: 2, concentration: "2.5 mg/mL", note: "~50 doses at 100 mcg; ~7-week supply" },
      { mg: 10, bac: 2, concentration: "5 mg/mL",   note: "~100 doses at 100 mcg; ~14-week supply" },
      { mg: 15, bac: 3, concentration: "5 mg/mL",   note: "~150 doses at 100 mcg" },
      { mg: 20, bac: 4, concentration: "5 mg/mL",   note: "~67 doses at 300 mcg; ~10-week supply" },
      { mg: 30, bac: 5, concentration: "6 mg/mL",   note: "~100 doses at 300 mcg" },
    ],
    tiers: {
      low:  { label: "100 mcg/day",  conservativeLabel: "50–100 mcg/day",  items: [{ icon: "🎯", label: "Start", detail: "100 mcg subQ once daily weeks 1–2.", conservative: "50 mcg/day for first week; 100 mcg from week 2 if tolerated." },{ icon: "⚡", label: "Effect", detail: "Gentle GH pulse, deeper sleep.", conservative: "Sleep improvement is the first indicator; monitor this closely." },{ icon: "🔁", label: "Frequency", detail: "Once daily pre-bed.", conservative: "Once daily pre-bed strictly." },{ icon: "📅", label: "Duration", detail: "8 weeks entry protocol.", conservative: "8–10 weeks; track sleep quality as outcome measure." },{ icon: "⏱", label: "Timing", detail: "Pre-bed fasted 2+ hours.", conservative: "Pre-bed; fasted 2–3 hours. No carbs in final meal." }] },
      mid:  { label: "200 mcg/day",  conservativeLabel: "100–150 mcg/day", items: [{ icon: "🎯", label: "Start", detail: "200 mcg/day; often stacked with CJC.", conservative: "100–150 mcg/day; stack with CJC only after 4 weeks solo." },{ icon: "⚡", label: "Effect", detail: "Recovery improvement, body composition support.", conservative: "Recovery improvement is measurable at 100–150 mcg; gradual is sustainable." },{ icon: "🔁", label: "Frequency", detail: "Once or twice daily.", conservative: "Once daily only at conservative tier." },{ icon: "📅", label: "Duration", detail: "12–16 week cycle.", conservative: "12 weeks; assess IGF-1 at 6 weeks." },{ icon: "⏱", label: "Timing", detail: "Pre-bed primary dose; AM fasted if splitting.", conservative: "Pre-bed primary; no morning dose at conservative level." }] },
      high: { label: "300 mcg/day",  conservativeLabel: "200 mcg/day",     items: [{ icon: "🎯", label: "Start", detail: "300 mcg/day performance protocol.", conservative: "200 mcg/day cap; 300 mcg offers modest additional benefit with more desensitization risk." },{ icon: "⚡", label: "Effect", detail: "Strong GH elevation; lean mass, fat metabolism, sleep.", conservative: "Lean mass effects at 200 mcg are real. Patience outperforms dose-chasing." },{ icon: "🔁", label: "Frequency", detail: "100 mcg 3x daily or 300 mcg pre-bed.", conservative: "200 mcg pre-bed only. Split dosing not recommended at conservative level." },{ icon: "📅", label: "Duration", detail: "12 weeks on, 4 off.", conservative: "12 weeks on; mandatory 4-week break to prevent receptor desensitization." },{ icon: "⏱", label: "Timing", detail: "Pre-workout + pre-bed windows.", conservative: "Pre-bed only; fasted 2+ hours." }] },
    },
  },
  {
    id: "mt2", name: "MT-2", short: "MT2", tag: "Melanocortin", color: "#FB923C",
    subtitle: "Melanotan II. Tanning & libido peptide.",
    storage: { opened: "30 days refrigerated (2–8°C)", unopened: "Until expiry frozen (−20°C)", light: "Very light-sensitive; keep wrapped or in original vial box" },
    reconSteps: [
      { icon: "🧴", title: "Gather supplies", text: "MT-2 vial, BAC water, insulin syringe, alcohol swabs." },
      { icon: "🧼", title: "Wash hands", text: "Thorough wash. Handle MT-2 carefully — it's highly active even at small doses." },
      { icon: "💧", title: "Swab both vials", text: "Clean both stoppers with fresh alcohol swabs." },
      { icon: "💉", title: "Draw BAC water precisely", text: "MT-2 is dosed in micrograms — precision in reconstitution is critical. Use a 1 mL syringe." },
      { icon: "🧪", title: "Inject gently", text: "Add BAC water slowly along the vial wall. MT-2 dissolves quickly." },
      { icon: "🔄", title: "Roll briefly", text: "10–15 second gentle roll. Avoid any shaking." },
      { icon: "🔍", title: "Check solution", text: "Should be clear and colorless. Discard if any color change is visible." },
      { icon: "🏷️", title: "Store with light protection", text: "Label and refrigerate immediately. Cover vial with foil or keep in box. UV light degrades MT-2 rapidly." },
    ],
    vials: [
      { mg: 5,  bac: 2, concentration: "2.5 mg/mL", note: "~20 doses at 250 mcg loading" },
      { mg: 10, bac: 2, concentration: "5 mg/mL",   note: "~40 doses at 250 mcg; full loading protocol" },
      { mg: 20, bac: 4, concentration: "5 mg/mL",   note: "~40 doses at 500 mcg; maintenance supply" },
      { mg: 30, bac: 5, concentration: "6 mg/mL",   note: "Extended supply for loading + maintenance" },
    ],
    tiers: {
      low:  { label: "250 mcg/day", conservativeLabel: "100–150 mcg/day", items: [{ icon: "🎯", label: "Start", detail: "250 mcg/day for loading phase weeks 1–2.", conservative: "100–150 mcg/day loading; MT-2 is very potent at even small doses." },{ icon: "⚡", label: "Effect", detail: "Mild melanin stimulation; assess nausea.", conservative: "Nausea, flushing, and facial redness are common — conservative start minimizes this." },{ icon: "🔁", label: "Frequency", detail: "Once daily; evening preferred.", conservative: "Once daily; strictly evening to sleep through side effects." },{ icon: "📅", label: "Duration", detail: "2-week load, then reduce.", conservative: "3–4 weeks at micro-dose before stepping up." },{ icon: "⏱", label: "Timing", detail: "Pre-bed to minimize nausea.", conservative: "Pre-bed always at conservative tier." }] },
      mid:  { label: "500 mcg/day", conservativeLabel: "250 mcg/day",     items: [{ icon: "🎯", label: "Start", detail: "500 mcg after tolerating 250 mcg loading.", conservative: "250 mcg/day; 500 mcg is often unnecessary for good tanning response." },{ icon: "⚡", label: "Effect", detail: "Visible tanning with UV; libido enhancement.", conservative: "Tanning occurs at 250 mcg with UV; libido improvement is common too." },{ icon: "🔁", label: "Frequency", detail: "Once daily; reduce to 2–3x/wk at saturation.", conservative: "2–3x weekly once initial response seen; avoid daily long-term." },{ icon: "📅", label: "Duration", detail: "3–4 weeks to saturation; maintenance after.", conservative: "4–5 weeks to saturation; maintenance 1–2x weekly." },{ icon: "⏱", label: "Timing", detail: "Evening; UV exposure following day.", conservative: "Evening; use sun protection even with MT-2 — don't overexpose." }] },
      high: { label: "1 mg/day",    conservativeLabel: "500 mcg/day",     items: [{ icon: "🎯", label: "Start", detail: "1 mg/day accelerated loading; experienced only.", conservative: "500 mcg/day is the conservative ceiling; 1 mg dramatically increases side effect risk." },{ icon: "⚡", label: "Effect", detail: "Rapid pigmentation, strong libido, appetite suppression.", conservative: "All effects present at 500 mcg. Higher dose is not proportionally more effective." },{ icon: "🔁", label: "Frequency", detail: "Once daily load; taper to 500 mcg maintenance.", conservative: "500 mcg max, taper to 250 mcg maintenance 2–3x weekly." },{ icon: "📅", label: "Duration", detail: "2-week max load; then 2–3x weekly.", conservative: "2-week max; monitor moles and skin carefully throughout." },{ icon: "⏱", label: "Timing", detail: "Pre-bed; monitor flushing and nausea.", conservative: "Pre-bed always; note any new moles or pigment changes." }] },
    },
  },
  {
    id: "nad", name: "NAD+", short: "NAD", tag: "Coenzyme", color: "#60A5FA",
    subtitle: "Cellular energy & longevity. IV or subQ.",
    storage: { opened: "7 days refrigerated (2–8°C)", unopened: "Until expiry frozen (−20°C)", light: "Moderately light-sensitive; refrigerate promptly" },
    reconSteps: [
      { icon: "🧴", title: "Gather supplies", text: "NAD+ vial, sterile saline or water for injection, IV bag (if drip), syringe, alcohol swabs." },
      { icon: "🧼", title: "Wash hands", text: "Full wash. Gloves recommended for IV preparation." },
      { icon: "💧", title: "Swab access points", text: "Clean all vial stoppers and IV ports thoroughly." },
      { icon: "💉", title: "Draw diluent", text: "For subQ: draw exact mL into insulin syringe. For IV: prepare per provider's saline bag instructions." },
      { icon: "🧪", title: "Reconstitute", text: "Add diluent slowly to NAD+ vial. NAD+ dissolves easily." },
      { icon: "🔄", title: "Mix gently", text: "Gentle swirl for 15–20 seconds. Do not shake." },
      { icon: "🔍", title: "Check appearance", text: "Should be clear. Very slight yellow tint is normal. Discard if dark yellow or brown." },
      { icon: "🏷️", title: "Use same day if IV", text: "For IV: use within same session. For subQ: refrigerate, use within 7 days. NAD+ degrades faster than most peptides." },
    ],
    vials: [
      { mg: 100,  bac: 5,  concentration: "20 mg/mL",  note: "Single session intro dose" },
      { mg: 250,  bac: 5,  concentration: "50 mg/mL",  note: "Single session standard low dose" },
      { mg: 500,  bac: 10, concentration: "50 mg/mL",  note: "Single IV session; standard optimization" },
      { mg: 1000, bac: 10, concentration: "100 mg/mL", note: "Single high-dose IV; slow drip required" },
      { mg: 3000, bac: 25, concentration: "120 mg/mL", note: "3-day intensive (1g/day); clinic use" },
      { mg: 5000, bac: 25, concentration: "200 mg/mL", note: "5-day or 10-day split intensive" },
    ],
    tiers: {
      low:  { label: "250 mg/session",  conservativeLabel: "100–250 mg/session", items: [{ icon: "🎯", label: "Start", detail: "250 mg IV slow drip or subQ for 5 days.", conservative: "100 mg/session for first 2 sessions; nausea and flushing are common at higher doses." },{ icon: "⚡", label: "Effect", detail: "Energy, mood, cognitive clarity.", conservative: "Energy and clarity improvements are noticeable even at 100–150 mg." },{ icon: "🔁", label: "Frequency", detail: "5-day load; then 1–2x weekly maintenance.", conservative: "3-day load first; then weekly maintenance." },{ icon: "📅", label: "Duration", detail: "5-day initial; monthly maintenance.", conservative: "3-session initial; bi-weekly maintenance is adequate." },{ icon: "⏱", label: "Timing", detail: "Morning; slow drip over 2–3 hours.", conservative: "Morning; very slow drip — 3–4 hours even at low doses." }] },
      mid:  { label: "500 mg/session",  conservativeLabel: "250–350 mg/session", items: [{ icon: "🎯", label: "Start", detail: "500 mg IV over 4 hours; standard dose.", conservative: "250–350 mg/session; achieve most of the benefit at lower intensity." },{ icon: "⚡", label: "Effect", detail: "Mitochondrial support, DNA repair, anti-aging.", conservative: "Mitochondrial effects are dose-dependent but plateau around 400 mg for most." },{ icon: "🔁", label: "Frequency", detail: "2–3x weekly or 5-day load then weekly.", conservative: "2x weekly or 5-day gentle load." },{ icon: "📅", label: "Duration", detail: "4–8 week protocol; quarterly cycles.", conservative: "6 weeks; quarterly maintenance." },{ icon: "⏱", label: "Timing", detail: "Morning clinic; slow drip reduces side effects.", conservative: "Slow drip always; 45–60 min per 100 mg is conservative target." }] },
      high: { label: "1000 mg/session", conservativeLabel: "500–750 mg/session", items: [{ icon: "🎯", label: "Start", detail: "1000 mg IV over 6–8 hours; clinical only.", conservative: "500–750 mg is clinically intense and far more manageable than 1g." },{ icon: "⚡", label: "Effect", detail: "Peak cellular restoration; intensive protocols.", conservative: "Most cellular restoration benefits present at 500–750 mg with less nausea." },{ icon: "🔁", label: "Frequency", detail: "Daily for 10-day intensive; monthly after.", conservative: "Every other day for 5 sessions; monthly after." },{ icon: "📅", label: "Duration", detail: "10-day intensive or 3x/week for 4 weeks.", conservative: "5–6 sessions over 2 weeks; then monthly maintenance." },{ icon: "⏱", label: "Timing", detail: "Full-day clinic commitment; very slow IV.", conservative: "Slow IV over 4–6 hours; clinic setting only." }] },
    },
  },
  {
    id: "tesamorelin", name: "Tesamorelin", short: "TESA", tag: "GHRH", color: "#F472B6",
    subtitle: "FDA-approved GHRH analogue. Daily subQ.",
    storage: { opened: "21 days refrigerated (2–8°C)", unopened: "Until expiry refrigerated (2–8°C) or frozen", light: "Light-sensitive; keep in original carton" },
    reconSteps: [
      { icon: "🧴", title: "Gather supplies", text: "Tesamorelin vial, sterile water for injection (provided with EGRIFTA kit or BAC water), 1 mL syringe, alcohol swabs." },
      { icon: "🧼", title: "Wash hands", text: "20-second wash. Dry completely." },
      { icon: "💧", title: "Swab stoppers", text: "Clean vial and water vial stoppers. Let dry 30 seconds." },
      { icon: "💉", title: "Draw 2.1 mL diluent", text: "For 2 mg dose: use the provided diluent syringe or draw 2.1 mL into a 3 mL syringe." },
      { icon: "🧪", title: "Inject into tesamorelin vial", text: "Inject diluent slowly against inner vial wall. Tesamorelin is fragile — no forceful injection." },
      { icon: "🔄", title: "Roll gently for 30 seconds", text: "Roll between palms. May take slightly longer to dissolve than other peptides — be patient." },
      { icon: "🔍", title: "Inspect solution", text: "Clear and colorless. Foam is OK; wait for it to settle before drawing. Discard if cloudy." },
      { icon: "🏷️", title: "Label & refrigerate", text: "Date and refrigerate immediately. Use within 21 days. Do not freeze reconstituted vial." },
    ],
    vials: [
      { mg: 1,  bac: 1, concentration: "1 mg/mL",   note: "Single dose vial; daily injection" },
      { mg: 2,  bac: 1, concentration: "2 mg/mL",   note: "Single dose or 2-day supply at 1 mg" },
      { mg: 5,  bac: 2, concentration: "2.5 mg/mL", note: "~5 days at 1 mg or 2.5 days at 2 mg" },
      { mg: 10, bac: 2, concentration: "5 mg/mL",   note: "~10 days at 1 mg; ~5 days at 2 mg" },
      { mg: 20, bac: 4, concentration: "5 mg/mL",   note: "~10-day supply at 2 mg/day" },
      { mg: 30, bac: 5, concentration: "6 mg/mL",   note: "~15-day supply at 2 mg/day" },
      { mg: 60, bac: 6, concentration: "10 mg/mL",  note: "30-day supply at 2 mg/day; 1-month kit" },
    ],
    tiers: {
      low:  { label: "1 mg/day",  conservativeLabel: "0.5–1 mg/day", items: [{ icon: "🎯", label: "Start", detail: "1 mg/day subQ weeks 1–4 to assess tolerance.", conservative: "0.5 mg/day for first 2 weeks; 1 mg after if well tolerated." },{ icon: "⚡", label: "Effect", detail: "Mild GH stimulation; early fat reduction.", conservative: "Visceral fat changes take 8+ weeks; don't expect rapid results." },{ icon: "🔁", label: "Frequency", detail: "Once daily subQ into abdomen.", conservative: "Once daily, same site rotation recommended." },{ icon: "📅", label: "Duration", detail: "8 weeks minimum to assess changes.", conservative: "10–12 weeks; IGF-1 check at 8 weeks." },{ icon: "⏱", label: "Timing", detail: "Pre-bed fasted for GH pulse.", conservative: "Pre-bed; fasted 2+ hours. No alcohol night of injection." }] },
      mid:  { label: "2 mg/day",  conservativeLabel: "1 mg/day",     items: [{ icon: "🎯", label: "Start", detail: "2 mg/day; FDA-approved standard dose.", conservative: "1 mg/day is effective; the FDA-approved 2 mg is not necessarily required for everyone." },{ icon: "⚡", label: "Effect", detail: "Clinically proven visceral fat reduction.", conservative: "Visceral fat reduction documented at both 1 mg and 2 mg." },{ icon: "🔁", label: "Frequency", detail: "Once daily subQ, abdomen.", conservative: "Once daily; rotate injection sites to reduce lipo-hypertrophy." },{ icon: "📅", label: "Duration", detail: "26 weeks per EGRIFTA trials.", conservative: "16–20 weeks; reassess with bloodwork before continuing." },{ icon: "⏱", label: "Timing", detail: "Pre-bed; fasted 2+ hours.", conservative: "Pre-bed consistently; track injection sites in a log." }] },
      high: { label: "4 mg/day",  conservativeLabel: "2 mg/day",     items: [{ icon: "🎯", label: "Start", detail: "4 mg/day off-label; experienced users only.", conservative: "2 mg/day is the studied ceiling; 4 mg is off-label with limited safety data." },{ icon: "⚡", label: "Effect", detail: "Amplified IGF-1, aggressive body recomp.", conservative: "Strong recomp effects at 2 mg/day; 4 mg benefit is not well-established." },{ icon: "🔁", label: "Frequency", detail: "2 mg AM + 2 mg PM; monitor IGF-1.", conservative: "2 mg once daily only; split dosing not recommended without clinical guidance." },{ icon: "📅", label: "Duration", detail: "12–16 weeks; mandatory IGF-1 blood monitoring.", conservative: "12 weeks max; IGF-1 at start, week 6, and end of cycle." },{ icon: "⏱", label: "Timing", detail: "Split AM/PM fasted when possible.", conservative: "Once daily pre-bed only at conservative level." }] },
    },
  },
  {
    id: "tb500", name: "TB-500", short: "TB5", tag: "Thymosin β4", color: "#E879F9",
    subtitle: "Thymosin beta-4 fragment. Healing & recovery.",
    storage: { opened: "30 days refrigerated (2–8°C)", unopened: "Until expiry frozen (−20°C)", light: "Store away from direct light" },
    reconSteps: [
      { icon: "🧴", title: "Gather supplies", text: "TB-500 vial, BAC water, syringe, alcohol swabs." },
      { icon: "🧼", title: "Wash hands", text: "20 seconds thorough wash." },
      { icon: "💧", title: "Swab vial tops", text: "Separate swabs for each vial. Let dry." },
      { icon: "💉", title: "Draw BAC water", text: "TB-500 comes in larger doses — a 3 mL syringe may be easier than an insulin syringe for larger vials." },
      { icon: "🧪", title: "Add to peptide vial", text: "Inject slowly along inside wall. TB-500 is a larger peptide and may take slightly longer to reconstitute." },
      { icon: "🔄", title: "Roll for 60 seconds", text: "Patient rolling is important here. Do not rush. Complete dissolution is essential." },
      { icon: "🔍", title: "Check clarity", text: "Should be clear. Minor white particulate that dissolves with continued rolling is OK. Discard if it persists." },
      { icon: "🏷️", title: "Label & refrigerate", text: "Date and refrigerate immediately. TB-500 is stable 30 days refrigerated." },
    ],
    vials: [
      { mg: 2,  bac: 1, concentration: "2 mg/mL",   note: "~1 weekly dose at 2 mg" },
      { mg: 5,  bac: 2, concentration: "2.5 mg/mL", note: "~2 weekly doses at 2.5 mg" },
      { mg: 10, bac: 2, concentration: "5 mg/mL",   note: "~4 weekly doses at 2.5 mg; 1-month supply" },
      { mg: 15, bac: 3, concentration: "5 mg/mL",   note: "~6 weekly doses at 2.5 mg" },
      { mg: 20, bac: 4, concentration: "5 mg/mL",   note: "~4 weekly doses at 5 mg" },
      { mg: 30, bac: 5, concentration: "6 mg/mL",   note: "~6 weekly doses at 5 mg; 6-week supply" },
      { mg: 50, bac: 5, concentration: "10 mg/mL",  note: "~10 weekly doses at 5 mg; bulk supply" },
    ],
    tiers: {
      low:  { label: "2.5 mg/wk",  conservativeLabel: "1–2 mg/wk",   items: [{ icon: "🎯", label: "Start", detail: "2.5 mg/week subQ for 4–6 weeks.", conservative: "1–2 mg/week; anti-inflammatory effects begin at sub-2.5 mg doses." },{ icon: "⚡", label: "Effect", detail: "Mild anti-inflammatory; early tissue repair.", conservative: "Tissue signaling begins at low doses; allow 3–4 weeks before judging." },{ icon: "🔁", label: "Frequency", detail: "Once weekly subQ.", conservative: "Once weekly; can split to 0.5–1 mg twice weekly." },{ icon: "📅", label: "Duration", detail: "4–6 week loading phase.", conservative: "6–8 weeks at conservative dose before assessing." },{ icon: "⏱", label: "Timing", detail: "Consistent weekly window.", conservative: "Post-workout or pre-bed; consistent day weekly." }] },
      mid:  { label: "5 mg/wk",    conservativeLabel: "2.5 mg/wk",   items: [{ icon: "🎯", label: "Start", detail: "5 mg/week; standard healing dose.", conservative: "2.5 mg/week is the conservative standard; proven effective in most cases." },{ icon: "⚡", label: "Effect", detail: "Accelerated soft tissue repair, reduced inflammation.", conservative: "Soft tissue repair documented at 2.5 mg/week; patience yields results." },{ icon: "🔁", label: "Frequency", detail: "Once weekly or 2.5 mg twice weekly.", conservative: "Once weekly at 2.5 mg; simple and effective." },{ icon: "📅", label: "Duration", detail: "4–6 week load; 2.5 mg/wk maintenance.", conservative: "6 weeks; then 2 mg/wk maintenance for 8 weeks." },{ icon: "⏱", label: "Timing", detail: "Post-workout or pre-bed.", conservative: "Post-workout; align with injury site's recovery window." }] },
      high: { label: "10 mg/wk",   conservativeLabel: "5 mg/wk",     items: [{ icon: "🎯", label: "Start", detail: "10 mg/week for acute injury recovery.", conservative: "5 mg/week is effective for acute protocols; 10 mg is rarely necessary." },{ icon: "⚡", label: "Effect", detail: "Rapid angiogenesis, muscle and nerve repair.", conservative: "Angiogenesis and nerve support present at 5 mg; conservative and effective." },{ icon: "🔁", label: "Frequency", detail: "5 mg twice weekly; provider supervision.", conservative: "2.5 mg twice weekly; provider check-in at 4 weeks." },{ icon: "📅", label: "Duration", detail: "4–6 weeks acute; taper to 5 mg/wk.", conservative: "6 weeks at 5 mg; taper to 2.5 mg for 4 more weeks." },{ icon: "⏱", label: "Timing", detail: "Morning + evening split preferred.", conservative: "Post-workout timing when possible; consistent days." }] },
    },
  },
];

const TIER_META = {
  low:  { label: "Low",  color: "#22C98A" },
  mid:  { label: "Mid",  color: "#F59E0B" },
  high: { label: "High", color: "#FF6B6B" },
};

// ─── COMPONENT ───────────────────────────────────────────────────────────────

export default function InventoryProtocols() {
  const [activeIdx, setActiveIdx]   = useState(0);
  const [tier, setTier]             = useState("mid");
  const [vialIdx, setVialIdx]       = useState(0);
  const [conservative, setConservative] = useState(false);
  const [tab, setTab]               = useState("protocol");
  const [hoveredItem, setHoveredItem] = useState(null);
  const [reconStep, setReconStep]   = useState(null);
  const [shareOpen, setShareOpen]   = useState(false);
  const [copied, setCopied]         = useState(false);

  const p    = protocols[activeIdx];
  const d    = p.tiers[tier];
  const vial = p.vials[vialIdx];

  const shareUrl    = typeof window !== "undefined" ? window.location.href : "https://protocol-library.app";
  const shareText   = `🧬 Check out this Peptide Protocol Library — dosing, reconstitution, storage & conservative mode for ${protocols.map(x => x.name).join(", ")} and more.`;
  const discordUrl  = `https://discord.com/channels/@me`;
  const smsUrl      = `sms:?body=${encodeURIComponent(shareText + "\n" + shareUrl)}`;
  const twitterUrl  = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleNativeShare = () => {
    if (navigator.share) {
      navigator.share({ title: "Peptide Protocol Library", text: shareText, url: shareUrl });
    } else {
      handleCopy();
    }
  };

  const handleCompound = (i) => { setActiveIdx(i); setVialIdx(0); setHoveredItem(null); setReconStep(null); setTab("protocol"); setShareOpen(false); };

  const fmtMg = (mg) => mg >= 1000 ? `${mg / 1000}g` : `${mg}mg`;

  return (
    <div style={{ minHeight: "100vh", background: "#0D0F13", display: "flex", flexDirection: "column", alignItems: "center", fontFamily: "'DM Sans', sans-serif", padding: "32px 16px 72px" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&family=DM+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }

        .eyebrow { display:flex; align-items:center; gap:7px; margin-bottom:4px; }
        .eyebrow-text { font-size:11px; font-weight:700; letter-spacing:2.5px; text-transform:uppercase; color:#2E323C; }
        .page-title { font-size:22px; font-weight:700; color:#E8E3DA; margin-bottom:20px; text-align:center; letter-spacing:-.3px; }

        /* Conservative toggle */
        .cons-toggle-wrap { display:flex; align-items:center; gap:10px; margin-bottom:20px; padding:10px 16px; background:#0F1116; border:1px solid #1A1D26; border-radius:12px; cursor:pointer; transition:border-color .2s; user-select:none; }
        .cons-toggle-wrap:hover { border-color:#2C3040; }
        .cons-toggle-wrap.on { border-color:#22C98A44; background:#0F1F18; }
        .toggle-track { width:36px; height:20px; border-radius:999px; background:#1A1D26; border:1px solid #2C3040; position:relative; transition:background .2s; flex-shrink:0; }
        .toggle-track.on { background:#22C98A33; border-color:#22C98A; }
        .toggle-thumb { position:absolute; top:3px; left:3px; width:12px; height:12px; border-radius:50%; background:#3A3F4A; transition:all .2s; }
        .toggle-thumb.on { left:19px; background:#22C98A; box-shadow:0 0 6px #22C98A; }
        .cons-label { font-size:13px; font-weight:600; color:#505566; transition:color .2s; }
        .cons-label.on { color:#22C98A; }
        .cons-desc { font-size:11.5px; color:#3A3F4A; line-height:1.4; }
        .cons-shield { font-size:16px; }

        /* Compound pills */
        .compound-grid { display:flex; flex-wrap:wrap; gap:6px; justify-content:center; max-width:520px; margin-bottom:20px; }
        .cpill { padding:6px 12px; border-radius:999px; border:1px solid #1A1D26; background:#0F1116; color:#3A3F4A; font-size:12px; font-weight:600; font-family:'DM Sans',sans-serif; cursor:pointer; transition:all .15s; display:flex; align-items:center; gap:5px; white-space:nowrap; }
        .cpill:hover { border-color:#2C3040; color:#7A8090; }
        .cpill.active { background:var(--c); border-color:var(--c); color:#fff; box-shadow:0 0 16px -5px var(--c); }
        .cpill-short { font-size:9px; font-weight:700; letter-spacing:.4px; padding:1.5px 5px; border-radius:4px; background:rgba(255,255,255,.14); }

        /* Card */
        .card { background:#111318; border:1px solid #1A1D26; border-radius:22px; padding:26px 22px 22px; width:100%; max-width:460px; position:relative; overflow:hidden; }
        .card-shimmer { position:absolute; top:0; left:0; right:0; height:1px; }

        .card-head { display:flex; justify-content:space-between; align-items:flex-start; gap:10px; margin-bottom:3px; }
        .card-name { font-size:19px; font-weight:700; color:#E8E3DA; line-height:1.2; }
        .card-badges { display:flex; flex-direction:column; align-items:flex-end; gap:4px; flex-shrink:0; }
        .badge { font-size:9.5px; font-weight:700; letter-spacing:.7px; text-transform:uppercase; padding:3px 7px; border-radius:5px; }
        .card-sub { font-size:12.5px; color:#3A3F4A; margin-bottom:18px; margin-top:2px; }

        /* Tab bar */
        .tab-bar { display:flex; gap:0; background:#0A0C10; border:1px solid #1A1D26; border-radius:11px; padding:3px; margin-bottom:16px; }
        .tab-btn { flex:1; padding:7px 8px; border-radius:8px; border:none; background:transparent; color:#3A3F4A; font-size:11.5px; font-weight:600; font-family:'DM Sans',sans-serif; cursor:pointer; transition:all .15s; white-space:nowrap; }
        .tab-btn:hover { color:#7A8090; }
        .tab-btn.active { background:#161820; color:#E8E3DA; box-shadow:0 1px 6px rgba(0,0,0,.4); }

        /* Tier selector */
        .tier-bar { display:flex; gap:0; background:#0A0C10; border:1px solid #1A1D26; border-radius:10px; padding:3px; margin-bottom:14px; }
        .tbtn { flex:1; padding:6px 8px; border-radius:7px; border:none; background:transparent; color:#3A3F4A; font-size:12px; font-weight:600; font-family:'DM Sans',sans-serif; cursor:pointer; transition:all .15s; display:flex; align-items:center; justify-content:center; gap:5px; }
        .tbtn:hover { color:#7A8090; }
        .tbtn.active { background:#161820; color:#E8E3DA; box-shadow:0 1px 5px rgba(0,0,0,.35); }
        .tdot { width:6px; height:6px; border-radius:50%; flex-shrink:0; }

        /* Vial selector */
        .section-label { font-size:10px; font-weight:700; letter-spacing:1.5px; text-transform:uppercase; color:#2E323C; margin-bottom:7px; }
        .vial-grid { display:flex; flex-wrap:wrap; gap:5px; margin-bottom:12px; }
        .vbtn { padding:5px 11px; border-radius:7px; border:1px solid #1A1D26; background:#0A0C10; color:#404550; font-size:11.5px; font-weight:700; font-family:'DM Mono',monospace; cursor:pointer; transition:all .15s; white-space:nowrap; }
        .vbtn:hover { border-color:#2C3040; color:#7A8090; }
        .vbtn.active { background:var(--vc); border-color:var(--vc); color:#fff; box-shadow:0 0 10px -3px var(--vc); }

        /* Vial info */
        .vial-info { background:#0A0C10; border:1px solid #1A1D26; border-radius:10px; padding:10px 13px; margin-bottom:16px; display:flex; flex-wrap:wrap; gap:10px; }
        .vinfo-item { display:flex; flex-direction:column; gap:2px; }
        .vinfo-key { font-size:9px; font-weight:700; letter-spacing:1.5px; text-transform:uppercase; color:#2E323C; }
        .vinfo-val { font-size:12.5px; font-weight:600; color:#C8CDD8; font-family:'DM Mono',monospace; }
        .vinfo-note { width:100%; font-size:11px; color:#404550; border-top:1px solid #1A1D26; padding-top:7px; margin-top:2px; line-height:1.4; }

        .divider { height:1px; background:#1A1D26; margin-bottom:14px; }

        /* Protocol items */
        .item-list { display:flex; flex-direction:column; }
        .pitem { display:flex; align-items:flex-start; gap:11px; padding:10px 8px; border-radius:9px; cursor:default; transition:background .12s; position:relative; }
        .pitem:not(:last-child)::after { content:''; position:absolute; bottom:0; left:38px; right:8px; height:1px; background:#1A1D26; }
        .pitem.hov { background:rgba(255,255,255,.02); }
        .iicon { width:30px; height:30px; border-radius:7px; background:#0A0C10; border:1px solid #1A1D26; display:flex; align-items:center; justify-content:center; flex-shrink:0; font-size:12px; transition:border-color .12s; }
        .pitem.hov .iicon { border-color:var(--accent); }
        .ilabel { font-size:12px; font-weight:700; margin-bottom:2px; }
        .idetail { font-size:11.5px; color:#404550; line-height:1.5; }
        .cons-detail { font-size:11px; color:#22C98A99; background:#0A1A12; border:1px solid #22C98A22; border-radius:6px; padding:5px 8px; margin-top:5px; line-height:1.45; }

        /* Reconstitution steps */
        .recon-grid { display:flex; flex-direction:column; gap:6px; }
        .recon-step { display:flex; align-items:flex-start; gap:10px; padding:10px; border-radius:10px; border:1px solid #1A1D26; background:#0A0C10; cursor:pointer; transition:all .15s; }
        .recon-step:hover { border-color:#2C3040; background:#111318; }
        .recon-step.open { border-color:var(--accent); background:#0F1318; }
        .recon-num { width:22px; height:22px; border-radius:6px; background:#161820; border:1px solid #1A1D26; display:flex; align-items:center; justify-content:center; font-size:10px; font-weight:700; color:#404550; flex-shrink:0; font-family:'DM Mono',monospace; }
        .recon-step.open .recon-num { background:var(--accent); border-color:var(--accent); color:#fff; }
        .recon-icon { font-size:14px; flex-shrink:0; }
        .recon-title { font-size:12.5px; font-weight:700; color:#C8CDD8; }
        .recon-body { font-size:11.5px; color:#505566; margin-top:4px; line-height:1.5; }

        /* Storage */
        .storage-grid { display:flex; flex-direction:column; gap:8px; }
        .storage-item { display:flex; align-items:flex-start; gap:10px; padding:11px 13px; border-radius:10px; background:#0A0C10; border:1px solid #1A1D26; }
        .storage-icon { font-size:18px; flex-shrink:0; }
        .storage-key { font-size:10px; font-weight:700; letter-spacing:1px; text-transform:uppercase; color:#3A3F4A; margin-bottom:3px; }
        .storage-val { font-size:13px; font-weight:600; color:#C8CDD8; }

        .footer-note { margin-top:14px; display:flex; align-items:flex-start; gap:8px; padding:8px 12px; background:rgba(255,255,255,.015); border:1px solid #1A1D26; border-radius:8px; }
        .fnote-dot { width:5px; height:5px; border-radius:50%; flex-shrink:0; margin-top:4px; }
        .fnote-text { font-size:10.5px; color:#2E323C; font-weight:500; line-height:1.45; }

        /* Share */
        .share-btn { display:flex; align-items:center; gap:6px; padding:7px 14px; border-radius:999px; border:1px solid #1A1D26; background:#111318; color:#6B7280; font-size:12.5px; font-weight:600; font-family:'DM Sans',sans-serif; cursor:pointer; transition:all .15s; flex-shrink:0; }
        .share-btn:hover { border-color:#2C3040; color:#C8CDD8; background:#161820; }
        .share-sheet { position:absolute; top:calc(100% + 8px); right:0; z-index:100; background:#13151C; border:1px solid #252830; border-radius:16px; padding:16px; width:280px; box-shadow:0 16px 48px rgba(0,0,0,.7); }
        .share-sheet-title { font-size:11px; font-weight:700; letter-spacing:1.5px; text-transform:uppercase; color:#3A3F4A; margin-bottom:12px; }
        .share-url-row { display:flex; align-items:center; gap:8px; background:#0A0C10; border:1px solid #1A1D26; border-radius:9px; padding:7px 10px; margin-bottom:12px; }
        .share-url-text { flex:1; font-size:11px; color:#404550; font-family:'DM Mono',monospace; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        .share-copy-btn { padding:4px 10px; border-radius:6px; border:1px solid #2C3040; background:#161820; color:#C8CDD8; font-size:11px; font-weight:700; font-family:'DM Sans',sans-serif; cursor:pointer; white-space:nowrap; transition:all .15s; flex-shrink:0; }
        .share-options { display:flex; flex-direction:column; gap:6px; }
        .share-option { display:flex; align-items:center; gap:9px; padding:9px 12px; border-radius:10px; border:1px solid #1A1D26; background:#0A0C10; font-size:12.5px; font-weight:600; font-family:'DM Sans',sans-serif; cursor:pointer; transition:all .15s; text-decoration:none; color:#C8CDD8; }
        .share-option:hover { background:#111318; border-color:#2C3040; }
        .share-option.discord { color:#5865F2; border-color:#5865F222; background:#0D0E1A; }
        .share-option.discord:hover { background:#11122A; border-color:#5865F244; }
        .share-option.sms { color:#30D158; border-color:#30D15822; background:#0A1510; }
        .share-option.sms:hover { background:#0D1A12; border-color:#30D15844; }
        .share-option.twitter { color:#E8E3DA; border-color:#1A1D26; }
        .share-option.native { color:#7A8090; border-color:#1A1D26; background:transparent; }

        @media (max-width:460px) {
          .card { padding:18px 14px 16px; }
          .tab-btn { font-size:10.5px; padding:6px 5px; }
          .vbtn { font-size:11px; padding:5px 9px; }
        }
      `}</style>

      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10, marginBottom: 20, position: "relative", width: "100%", maxWidth: 460 }}>
        <h1 className="page-title" style={{ margin: 0 }}>Protocol Library</h1>
        <button className="share-btn" onClick={() => setShareOpen(s => !s)}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
          Share
        </button>
        {shareOpen && (
          <div className="share-sheet">
            <div className="share-sheet-title">Share Protocol Library</div>
            <div className="share-url-row">
              <span className="share-url-text">{shareUrl}</span>
              <button className="share-copy-btn" onClick={handleCopy} style={{ background: copied ? "#22C98A22" : undefined, color: copied ? "#22C98A" : undefined, borderColor: copied ? "#22C98A44" : undefined }}>
                {copied ? "✓ Copied" : "Copy"}
              </button>
            </div>
            <div className="share-options">
              <a className="share-option discord" href={discordUrl} target="_blank" rel="noreferrer">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057c.002.022.015.043.033.056a19.93 19.93 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.055c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/></svg>
                Discord
              </a>
              <a className="share-option sms" href={smsUrl}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                iMessage
              </a>
              <a className="share-option twitter" href={twitterUrl} target="_blank" rel="noreferrer">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                Post on X
              </a>
              <button className="share-option native" onClick={handleNativeShare}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg>
                More…
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Conservative mode toggle */}
      <div className={`cons-toggle-wrap${conservative ? " on" : ""}`} style={{ maxWidth: 460, width: "100%" }} onClick={() => setConservative(c => !c)}>
        <span className="cons-shield">{conservative ? "🛡️" : "⚗️"}</span>
        <div style={{ flex: 1 }}>
          <div className={`cons-label${conservative ? " on" : ""}`}>Conservative Mode {conservative ? "On" : "Off"}</div>
          <div className="cons-desc">{conservative ? "Showing safer, lower-range doses for each protocol." : "Showing standard dosing. Enable for lower, extra-safe ranges."}</div>
        </div>
        <div className={`toggle-track${conservative ? " on" : ""}`}>
          <div className={`toggle-thumb${conservative ? " on" : ""}`} />
        </div>
      </div>

      {/* Compound pills */}
      <div className="compound-grid">
        {protocols.map((proto, i) => (
          <button key={proto.id} className={`cpill${activeIdx === i ? " active" : ""}`} style={{ "--c": proto.color }} onClick={() => handleCompound(i)}>
            {proto.name}
            <span className="cpill-short">{proto.short}</span>
          </button>
        ))}
      </div>

      {/* Card */}
      <div className="card" style={{ "--accent": p.color, boxShadow: `0 8px 48px rgba(0,0,0,.5), 0 0 60px -24px ${p.color}28` }}>
        <div className="card-shimmer" style={{ background: `linear-gradient(90deg, transparent, ${p.color}45, transparent)` }} />

        <div className="card-head">
          <h2 className="card-name">{p.name}</h2>
          <div className="card-badges">
            <span className="badge" style={{ background: `${p.color}20`, color: p.color }}>{p.tag}</span>
            {conservative && <span className="badge" style={{ background: "#22C98A18", color: "#22C98A" }}>🛡️ Conservative</span>}
          </div>
        </div>
        <p className="card-sub">{p.subtitle}</p>

        {/* Tab bar */}
        <div className="tab-bar">
          {[["protocol", "📋 Protocol"], ["reconstitution", "🧪 Reconstitution"], ["storage", "🧊 Storage"]].map(([key, label]) => (
            <button key={key} className={`tab-btn${tab === key ? " active" : ""}`} onClick={() => setTab(key)}>{label}</button>
          ))}
        </div>

        {/* ── PROTOCOL TAB ── */}
        {tab === "protocol" && <>
          {/* Tier */}
          <div className="tier-bar">
            {Object.entries(TIER_META).map(([key, meta]) => (
              <button key={key} className={`tbtn${tier === key ? " active" : ""}`} onClick={() => setTier(key)}>
                <span className="tdot" style={{ background: meta.color, boxShadow: tier === key ? `0 0 5px ${meta.color}` : "none" }} />
                {meta.label}
              </button>
            ))}
          </div>

          {/* Dose label */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
            <span className="section-label" style={{ margin: 0 }}>Dose Range</span>
            <span style={{ fontSize: 12, fontWeight: 700, padding: "2px 9px", borderRadius: 6, background: `${TIER_META[tier].color}18`, color: TIER_META[tier].color, fontFamily: "'DM Mono', monospace" }}>
              {conservative ? d.conservativeLabel : d.label}
            </span>
          </div>

          {/* Vial selector */}
          <div className="section-label">Vial Size</div>
          <div className="vial-grid">
            {p.vials.map((v, i) => (
              <button key={i} className={`vbtn${vialIdx === i ? " active" : ""}`} style={{ "--vc": p.color }} onClick={() => setVialIdx(i)}>
                {fmtMg(v.mg)}
              </button>
            ))}
          </div>

          {/* Vial info */}
          <div className="vial-info">
            <div className="vinfo-item">
              <span className="vinfo-key">Vial Size</span>
              <span className="vinfo-val" style={{ color: p.color }}>{fmtMg(vial.mg)}</span>
            </div>
            <div className="vinfo-item">
              <span className="vinfo-key">BAC Water</span>
              <span className="vinfo-val">{vial.bac} mL</span>
            </div>
            <div className="vinfo-item">
              <span className="vinfo-key">Concentration</span>
              <span className="vinfo-val">{vial.concentration}</span>
            </div>
            <div className="vinfo-note">💡 {vial.note}</div>
          </div>

          <div className="divider" />

          {/* Protocol items */}
          <div className="item-list">
            {d.items.map((item, i) => (
              <div key={i} className={`pitem${hoveredItem === i ? " hov" : ""}`} onMouseEnter={() => setHoveredItem(i)} onMouseLeave={() => setHoveredItem(null)}>
                <div className="iicon">{item.icon}</div>
                <div style={{ flex: 1, paddingTop: 1 }}>
                  <div className="ilabel" style={{ color: p.color }}>{item.label}</div>
                  <div className="idetail">{item.detail}</div>
                  {conservative && item.conservative && (
                    <div className="cons-detail">🛡️ {item.conservative}</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </>}

        {/* ── RECONSTITUTION TAB ── */}
        {tab === "reconstitution" && <>
          <div style={{ marginBottom: 12 }}>
            <div className="section-label">Step-by-Step Guide</div>
            <div style={{ fontSize: 11.5, color: "#3A3F4A", marginTop: 2 }}>Tap any step for details.</div>
          </div>
          <div className="recon-grid">
            {p.reconSteps.map((step, i) => (
              <div key={i} className={`recon-step${reconStep === i ? " open" : ""}`} style={{ "--accent": p.color }} onClick={() => setReconStep(reconStep === i ? null : i)}>
                <div className="recon-num">{i + 1}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                    <span className="recon-icon">{step.icon}</span>
                    <span className="recon-title">{step.title}</span>
                  </div>
                  {reconStep === i && <div className="recon-body">{step.text}</div>}
                </div>
                <span style={{ fontSize: 10, color: "#3A3F4A", flexShrink: 0, marginTop: 2 }}>{reconStep === i ? "▲" : "▼"}</span>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 14, padding: "10px 13px", background: "#0A0C10", border: "1px solid #1A1D26", borderRadius: 10 }}>
            <div className="section-label" style={{ marginBottom: 6 }}>Reconstitution Summary</div>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <div className="vinfo-item"><span className="vinfo-key">Vial</span><span className="vinfo-val" style={{ color: p.color }}>{fmtMg(vial.mg)}</span></div>
              <div className="vinfo-item"><span className="vinfo-key">BAC Water</span><span className="vinfo-val">{vial.bac} mL</span></div>
              <div className="vinfo-item"><span className="vinfo-key">Yield</span><span className="vinfo-val">{vial.concentration}</span></div>
            </div>
          </div>
        </>}

        {/* ── STORAGE TAB ── */}
        {tab === "storage" && <>
          <div className="section-label" style={{ marginBottom: 10 }}>Storage Guidelines</div>
          <div className="storage-grid">
            <div className="storage-item">
              <span className="storage-icon">🧊</span>
              <div><div className="storage-key">After Reconstitution</div><div className="storage-val">{p.storage.opened}</div></div>
            </div>
            <div className="storage-item">
              <span className="storage-icon">📦</span>
              <div><div className="storage-key">Unopened / Lyophilized</div><div className="storage-val">{p.storage.unopened}</div></div>
            </div>
            <div className="storage-item">
              <span className="storage-icon">💡</span>
              <div><div className="storage-key">Light Exposure</div><div className="storage-val">{p.storage.light}</div></div>
            </div>
            <div className="storage-item" style={{ background: conservative ? "#0A1A12" : "#0A0C10", borderColor: conservative ? "#22C98A22" : "#1A1D26" }}>
              <span className="storage-icon">🛡️</span>
              <div>
                <div className="storage-key">Conservative Storage Tips</div>
                <div className="storage-val" style={{ fontSize: 12, color: conservative ? "#22C98A" : "#404550" }}>
                  {conservative
                    ? "Always use the conservative end of the shelf-life window. Discard at 2/3 of max days even if appearance is normal. Double-bag in a zip-lock to protect from fridge odors and condensation."
                    : "Enable Conservative Mode to see extra-safe storage practices."}
                </div>
              </div>
            </div>
          </div>
        </>}

        <div className="footer-note">
          <div className="fnote-dot" style={{ background: p.color, marginTop: 4 }} />
          <span className="fnote-text">Patient education only. All protocols require licensed provider supervision. Individual results vary. This tool does not replace medical advice.</span>
        </div>
      </div>
    </div>
  );
}
