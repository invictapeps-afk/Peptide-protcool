# Peptide Protocol Library

Deploy to Vercel in 3 steps:

1. Go to vercel.com → **Add New Project**
2. Click **"Import Third-Party Git Repository"** or drag & drop this folder
3. Hit **Deploy** — no settings to change

Your site will be live at `your-project-name.vercel.app` in ~60 seconds.

---

To rename your URL: Vercel Dashboard → Project → Settings → Domains
